#!/usr/bin/env bash
set -euo pipefail

PROFILE="${1:-web}"
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if ! command -v dsh >/dev/null 2>&1; then
  echo "未找到 dsh 命令。请先确保 DSH CLI 在 PATH 中。" >&2
  exit 1
fi

echo "[1/2] 安装 dsh-better-sidebar 0.26.0 ..."
dsh plugin --profile "$PROFILE" add "$DIR/vendor/dsh-better-sidebar-0.26.0.tgz"

echo "[2/2] 安装 dsh-ai-mind 0.1.4 ..."
dsh plugin --profile "$PROFILE" add "$DIR/dsh-ai-mind-0.1.4.tgz"

cat <<EOF

安装完成。

请重启 DSH 使插件生效，例如：
  dsh web

重启后打开一个已有会话，右侧栏会自动出现「AI 心流」。
如果被关闭，可从右侧栏的 + 菜单重新打开。
EOF
